var BIBOX_HORNBILL_URL = 'http://school.bibox.in:33066/webbisoft/dfu/hornbill_usb';
//var BBIBOX_TERN_URL = 'http://school.bibox.in:33066/webbisoft/dfu/tern';
var BIBOX_STARLING = 'http://school.bibox.in:33066/webbisoft/dfu/starling';


exports.BIBOX_HORNBILL_URL = BIBOX_HORNBILL_URL; 
exports.BIBOX_STARLING = BIBOX_STARLING; 
