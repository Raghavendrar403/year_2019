/**
 * This module decribes the ItemTypes inn the workspace
 * @module components/assembly/ItemTypes
 */

module.exports = {
  BIBOX: 'bibox',
  COMPONENT: 'component',
  PORT_CIRCLE: 'port_circle'
};
