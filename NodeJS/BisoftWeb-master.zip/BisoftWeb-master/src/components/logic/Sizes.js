var Sizes = {
  r: 54,
  xdiff: 102,
  ydiff: 87,
}

module.exports = Sizes;
