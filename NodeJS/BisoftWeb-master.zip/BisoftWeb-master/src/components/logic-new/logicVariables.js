module.exports = {
  bic1: 'BI Counter 1',
  bic2: 'BI Counter 2',
  bic3: 'BI Counter 3',
  bif1: 'BI Flag 1',
  bif2: 'BI Flag 2',
  bif3: 'BI Flag 3',
  bid1: 'BI Data 1',
  bid2: 'BI Data 2',
  bid3: 'BI Data 3',
  bmp3: 'BTMp3',
  bpr: 'BEEPER',
  irr: 'IR Remote',
  btr: 'BT Remote',
  bts: 'BT Slider',
  edt: '--Edit Text--'
}
