var React = require('react');
var PropTypes = React.PropTypes;

var Empty = React.createClass({

  render: function() {
    return (
      <div>
        Empty
      </div>
    );
  }

});

module.exports = Empty;
