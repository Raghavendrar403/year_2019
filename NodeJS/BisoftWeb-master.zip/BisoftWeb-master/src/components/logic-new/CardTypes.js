module.exports = {
  CARD_IF: 'if',
  CARD_OUTPUT: 'output',
  CARD_LOOP: 'loop',
  CARD_START: 'start',
  CARD_WAIT: 'wait',
  CARD_INSERT: 'code',
  CARD_END: 'end',
}
