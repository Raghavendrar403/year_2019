var BUNDLE_TYPE = 'BLE';
var USE_EXE = true;

exports.BUNDLE_TYPE = BUNDLE_TYPE;
exports.USE_EXE = USE_EXE;