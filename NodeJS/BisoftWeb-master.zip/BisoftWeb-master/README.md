# BISFOT WEB

The world's first hexagonal programming platform is now available for download for various OS's and devices. BISOFT supports 3-in-1 programming construct. Multiple consoles like Remote, Audio, graph plotter, speech recognition, etc are available on the app. Single BISOFT software or app supports all variants of BIBOX Kit.
