This is the README file for BisoftApp.

In the Zadig tool window opened, First select 'List all devices' from options.
Out of devices listed, select your bluetooth device dongle and in driver option, select "libusb-win32 (v1.2.6.0)" and click on replace driver.
(Note: This will replace your default bluetooth driver with lib-win32 driver for bluetooth connectivity)
Once it is done, Take Bisoft Connectivity App and bluetooth devices will be listed. 
 
use http://localhost:9009 to open Bisoft App in browser